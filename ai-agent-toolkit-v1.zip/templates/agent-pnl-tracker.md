# Agent P&L Tracker Template

Copy this template. Update weekly. Kill agents that don't earn their keep.

---

## Weekly P&L — Week of [DATE]

### Per-Agent Breakdown

| Agent | Role | Queries | API Cost | Revenue Attributed | Hours Saved | Cost/Hour Saved |
|-------|------|---------|----------|--------------------|-------------|-----------------|
| [Name] | Coordinator | 0 | $0.00 | $0 | 2h | $0.00 |
| [Name] | Researcher | 0 | $0.00 | $0 | 5h | $0.00 |
| [Name] | Sales Intel | 0 | $0.00 | $0 | 3h | $0.00 |
| [Name] | Content | 0 | $0.00 | $0 | 4h | $0.00 |
| [Name] | Finance | 0 | $0.00 | $0 | 1h | $0.00 |
| **TOTAL** | | **0** | **$0.00** | **$0** | **15h** | **$0.00** |

### Fixed Costs

| Item | Monthly | Weekly |
|------|---------|--------|
| Claude Max subscription | $200 | $50 |
| Electricity (Mac Mini) | $15 | $3.75 |
| API overflow (estimated) | $7 | $1.75 |
| **Total fixed** | **$222** | **$55.50** |

### Summary

- **Total weekly cost:** $55.50 (fixed) + $0.00 (variable) = **$55.50**
- **Total weekly revenue:** $0
- **Total hours saved:** 15h
- **Effective hourly rate:** $3.70/hour saved
- **Break-even:** Need $55.50/week in revenue or 15h+/week in time savings at $4/hour

### Revenue Attribution Rules

1. **Direct:** Agent created the asset that generated revenue (e.g., sales page, product)
2. **Influenced:** Agent contributed to the pipeline (e.g., researched the lead that converted)
3. **Saved:** Agent did work a human would have done (value = hours × hourly rate)

When in doubt, attribute to the LAST agent that touched the revenue-generating activity.

### Kill Criteria

Flag an agent for removal if ALL of these are true for 2+ consecutive weeks:
- [ ] Revenue attributed: $0
- [ ] Hours saved: < 1 hour/week
- [ ] No other agent depends on its output
- [ ] Its tasks could be absorbed by another agent

### Growth Criteria

Add a new agent when:
- [ ] You are personally doing 5+ hours/week of a specific type of work
- [ ] An existing agent is overloaded (queue depth > 10 tasks)
- [ ] A new revenue stream requires domain-specific capabilities
- [ ] Budget allows ($14/month per agent at current rates)

---

## Historical Trend

| Week | Total Cost | Total Revenue | Net | Hours Saved | Agents |
|------|-----------|---------------|-----|-------------|--------|
| W1 | $55.50 | $0 | -$55.50 | 5h | 3 |
| W2 | $55.50 | $0 | -$55.50 | 8h | 3 |
| W3 | $55.50 | $0 | -$55.50 | 12h | 5 |
| W4 | $55.50 | $19 | -$36.50 | 15h | 7 |

Track the trend. If costs are rising faster than revenue + time savings, you're adding agents too fast.
