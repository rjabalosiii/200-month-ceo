/**
 * Budget Routing Configuration
 *
 * 3-tier LLM routing: Local → Flat-rate → API
 * This is the config that keeps 16 agents running under $210/month.
 *
 * HOW IT WORKS:
 * 1. Every request hits the local classifier first (qwen2.5:3b, ~50ms)
 * 2. Classifier decides: can a local model handle this, or does it need cloud?
 * 3. Simple tasks stay local (free). Complex tasks go to flat-rate (Claude Max).
 * 4. If flat-rate is saturated/rate-limited, overflow to pay-per-token API.
 *
 * CUSTOMIZE: Adjust thresholds, model names, and daily limits for your setup.
 */

export interface BudgetConfig {
  tiers: LLMTier[];
  perAgentDailyLimit: number;  // USD
  globalDailyLimit: number;    // USD
  alertThreshold: number;      // percentage (0.0-1.0)
  overflowEnabled: boolean;
}

export interface LLMTier {
  name: string;
  provider: 'local' | 'flat-rate' | 'api';
  model: string;
  costPerQuery: number;        // USD, 0 for local/flat-rate
  maxTokens: number;
  priority: number;            // lower = tried first
  rateLimit?: number;          // queries per minute
  capabilities: string[];     // what this tier can handle
}

export const budgetConfig: BudgetConfig = {
  tiers: [
    {
      name: 'classifier',
      provider: 'local',
      model: 'qwen2.5:3b',      // Runs in ~50ms on Apple Silicon
      costPerQuery: 0,
      maxTokens: 512,
      priority: 0,               // Always runs first
      capabilities: ['classify'],  // Only used for routing decisions
    },
    {
      name: 'local-worker',
      provider: 'local',
      model: 'qwen2.5:14b',     // Handles ~26% of all requests
      costPerQuery: 0,
      maxTokens: 4096,
      priority: 1,
      capabilities: [
        'summarize',             // Summarize documents
        'extract',               // Extract structured data
        'classify',              // Categorize items
        'format',                // Reformat text
        'simple-qa',             // Answer factual questions from context
      ],
    },
    {
      name: 'cloud-flat',
      provider: 'flat-rate',
      model: 'claude-sonnet',    // Via Claude Max subscription ($200/month)
      costPerQuery: 0,           // Flat rate = no per-query cost
      maxTokens: 200000,
      priority: 2,
      rateLimit: 60,             // Adjust based on your subscription tier
      capabilities: [
        'reason',                // Complex reasoning
        'code',                  // Code generation and review
        'strategy',              // Strategic analysis
        'creative',              // Creative writing
        'multi-step',            // Multi-step task planning
        'tool-use',              // Tool calling
      ],
    },
    {
      name: 'api-overflow',
      provider: 'api',
      model: 'claude-haiku',     // Cheapest capable model for overflow
      costPerQuery: 0.01,        // Approximate per-query cost
      maxTokens: 200000,
      priority: 3,               // Last resort
      capabilities: [
        'reason',
        'code',
        'strategy',
        'creative',
        'multi-step',
        'tool-use',
      ],
    },
  ],

  perAgentDailyLimit: 2.00,     // $2/day per agent max
  globalDailyLimit: 15.00,      // $15/day total across all agents
  alertThreshold: 0.80,         // Alert at 80% of budget
  overflowEnabled: true,        // Allow API fallback when flat-rate is saturated
};

/**
 * CLASSIFIER PROMPT
 *
 * This prompt runs on the local 3b model for every incoming request.
 * It decides which tier should handle the actual work.
 *
 * Keep this prompt SHORT — it runs on every single query.
 */
export const classifierPrompt = `Classify this request into one category:
- SIMPLE: summarization, data extraction, formatting, factual Q&A from given context
- COMPLEX: reasoning, code generation, strategy, creative writing, multi-step planning

Request: {request}

Reply with only: SIMPLE or COMPLEX`;

/**
 * ROUTING LOGIC (pseudocode)
 *
 * function routeRequest(request, agent):
 *   // 1. Check budget
 *   if agent.dailySpend >= perAgentDailyLimit:
 *     return BLOCKED ("Budget exceeded")
 *
 *   // 2. Classify
 *   classification = classifier.run(classifierPrompt, request)
 *
 *   // 3. Route
 *   if classification == SIMPLE:
 *     return localWorker.run(request)
 *
 *   if classification == COMPLEX:
 *     if cloudFlat.available():
 *       return cloudFlat.run(request)
 *     elif overflowEnabled:
 *       return apiOverflow.run(request)  // track cost!
 *     else:
 *       return QUEUED ("Rate limited, will retry")
 */
