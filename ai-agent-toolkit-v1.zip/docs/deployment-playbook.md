# 60-Day Deployment Playbook
## From Zero to 16 AI Agents in Production

### The Rule: Start With 2-3, Not 16

Every person who fails at multi-agent systems makes the same mistake: they build 10 agents on day one. You need exactly 3 to start:

1. **A coordinator** (routes tasks, manages schedule)
2. **A researcher** (web search, document analysis)
3. **A specialist** (whatever your actual business needs — sales, content, support)

Get these 3 stable. Then add one agent per week.

---

### Week 1-2: Foundation (2-3 agents)

**Build:**
- Agent registry (who exists, what they can do)
- Tool registry (what tools exist, who has access)
- Basic message routing (cron triggers → agent runs)

**Key Decision:** SQLite vs Postgres for task storage.
- If single machine: SQLite (simpler, no network)
- If distributed: Postgres (but you probably don't need this yet)

**Expected problems:**
- Agents hallucinating tool names → Fix: strict tool validation
- No budget controls → Fix: add basic per-query cost tracking day 1
- Agents responding to everything → Fix: add a classifier (even regex works)

**What "working" looks like:**
- Coordinator receives a task via cron
- Routes to correct agent
- Agent uses 1-2 tools
- Result persists to database

### Week 3-4: Budget Routing (critical)

**Build:**
- 3-tier LLM routing: local → flat-rate → API
- Per-agent tool limits (7-10 max)
- Budget tracking per agent per day

**The Routing Stack:**
```
Incoming request
  ↓
Local classifier (qwen2.5:3b, 50ms)
  → Simple? → Local model (qwen2.5:14b)
  → Complex? → Claude Max (flat rate)
  → Claude Max saturated? → API fallback (pay-per-token)
```

**Why this order matters:**
- Without local routing, 16 agents × 50 queries/day × $0.01 = $8/day = $240/month
- With local routing, 26% stay local (free), 70% go flat-rate ($200 fixed), 4% hit API (~$7)
- Savings: $240/month → $207/month, and it STAYS at $207 as you add agents

**Expected problems:**
- Local model quality too low → Fix: fine-tune classifier prompt, not the model
- Budget alerts not triggering → Fix: check budget BEFORE each query, not after
- Agent X consistently overspending → Fix: reduce its tool count (tools = tokens)

### Week 5-6: Inter-Agent Delegation

**Build:**
- Task schema (see src/task-schema.ts)
- Dependency tracking (Task C waits for A and B)
- Automatic retry with exponential backoff
- Quality gates (agent reviews its own output before marking complete)

**Why tasks beat messages:**
| Messages | Tasks |
|----------|-------|
| Fire and forget | Persistent in DB |
| No retry | Auto-retry on failure |
| No dependencies | DAG-based dependencies |
| No visibility | Full audit trail |

**Expected problems:**
- Circular dependencies → Fix: validate DAG before creating task
- Task queue growing forever → Fix: TTL per priority level (P0: 1h, P1: 4h, P2: 24h)
- Agent creating tasks for itself → Fix: block self-delegation

### Week 7-8: Specialization

**Add agents based on actual needs, not hypothetical ones:**
- Are you manually doing research? → Add research agent
- Are you manually writing content? → Add content agent
- Are you manually qualifying leads? → Add sales agent

**Each new agent needs:**
1. Soul file (role, personality, decision authority)
2. Tool allocation (7-10 tools, not more)
3. Budget allocation (share of the monthly pool)
4. Cooperation rules (who they talk to, when)

**Expected problems:**
- New agent interferes with existing agents → Fix: explicit scope boundaries in soul files
- Context window overflow → Fix: summarize, don't pass full history
- Agent personality drift → Fix: re-inject soul at every conversation start

### Week 9+: Revenue and Measurement

**Now measure:**
- Per-agent cost (API + compute)
- Per-agent revenue attribution (what deals did this agent influence?)
- Hours saved (what would a human have done?)

**Kill agents that don't earn:**
- If an agent costs $14/month and saves 0 hours → kill it
- If an agent costs $14/month and saves 2 hours/week → keep it ($1.75/hour is a steal)
- Revenue attribution is hard → default to "last agent to touch the deal"

---

### The 5 Things We'd Do Differently

1. **Start with budget routing, not agents.** We added budget controls in week 3. Should have been day 1. Cost us ~$200 in wasted API calls.

2. **Restrict tools immediately.** Our first agents had access to 30+ tools. Claude spent more tokens deciding which tool to use than actually using it.

3. **Build the task system before the 4th agent.** 3 agents can coordinate via simple messages. 4+ need structured tasks.

4. **Write soul files like job descriptions, not prompts.** "You are a sales analyst" is too vague. "You are Mariano, a sales intelligence specialist who thinks in buyer language and never contacts prospects directly" is actionable.

5. **Measure from day 1.** We didn't track per-agent costs until week 4. By then we'd wasted $400 on one agent that was calling Claude API for tasks a local model could handle.
