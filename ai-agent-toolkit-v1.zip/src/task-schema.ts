/**
 * Inter-Agent Task Delegation Schema
 *
 * Tasks replace messages for agent communication.
 * Why: persistence, retry, dependency tracking, audit trail.
 *
 * Every agent can create tasks for any other agent.
 * Tasks have dependencies — Task C waits until A and B complete.
 * Failed tasks retry with exponential backoff.
 * Everything persists to SQLite.
 */

// -- Core Types --

export type TaskPriority = 'P0' | 'P1' | 'P2' | 'P3';
export type TaskStatus = 'pending' | 'blocked' | 'in_progress' | 'completed' | 'failed' | 'cancelled';

export interface AgentTask {
  id: string;                    // Unique task ID (e.g., "q-abc12345")
  fromAgent: string;             // Who created this task
  toAgent: string;               // Who should execute it
  prompt: string;                // What to do (clear, specific instructions)
  priority: TaskPriority;        // P0 = do now, P3 = whenever
  status: TaskStatus;
  dependsOn: string[];           // Task IDs that must complete first
  resultText: string | null;     // Output when completed
  createdAt: string;             // ISO timestamp
  updatedAt: string;             // ISO timestamp
  completedAt: string | null;    // ISO timestamp when done
  retryCount: number;            // How many times this has been retried
  maxRetries: number;            // Max retry attempts (default: 3)
  ttlMinutes: number;            // Time-to-live before auto-cancel
  metadata: Record<string, unknown>; // Flexible metadata (tags, context, etc.)
}

// -- Priority TTL Defaults --

export const PRIORITY_TTL: Record<TaskPriority, number> = {
  P0: 60,    // 1 hour — urgent, do immediately
  P1: 240,   // 4 hours — important, do today
  P2: 1440,  // 24 hours — normal priority
  P3: 4320,  // 72 hours — low priority, do when free
};

// -- Retry Configuration --

export const RETRY_CONFIG = {
  maxRetries: 3,
  baseDelayMs: 5000,          // 5 seconds
  maxDelayMs: 300000,         // 5 minutes
  backoffMultiplier: 2,       // Exponential: 5s → 10s → 20s → ...
};

/**
 * Calculate retry delay with exponential backoff
 */
export function getRetryDelay(retryCount: number): number {
  const delay = RETRY_CONFIG.baseDelayMs * Math.pow(RETRY_CONFIG.backoffMultiplier, retryCount);
  return Math.min(delay, RETRY_CONFIG.maxDelayMs);
}

// -- Task Validation --

export interface TaskValidationResult {
  valid: boolean;
  errors: string[];
}

/**
 * Validate a task before creating it.
 * Catches common mistakes: circular deps, self-delegation, missing fields.
 */
export function validateTask(
  task: Partial<AgentTask>,
  existingTasks: AgentTask[]
): TaskValidationResult {
  const errors: string[] = [];

  // Required fields
  if (!task.fromAgent) errors.push('fromAgent is required');
  if (!task.toAgent) errors.push('toAgent is required');
  if (!task.prompt) errors.push('prompt is required');
  if (!task.priority) errors.push('priority is required');

  // No self-delegation
  if (task.fromAgent === task.toAgent) {
    errors.push('Agent cannot create tasks for itself');
  }

  // Check for circular dependencies
  if (task.dependsOn && task.dependsOn.length > 0) {
    for (const depId of task.dependsOn) {
      const depTask = existingTasks.find(t => t.id === depId);
      if (!depTask) {
        errors.push(`Dependency ${depId} does not exist`);
      } else if (depTask.status === 'cancelled' || depTask.status === 'failed') {
        errors.push(`Dependency ${depId} is ${depTask.status} — cannot depend on it`);
      }
    }
  }

  // Prompt quality check
  if (task.prompt && task.prompt.length < 20) {
    errors.push('Prompt is too short — be specific about what the agent should do');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

// -- Task Factory --

/**
 * Create a new task with sensible defaults.
 *
 * Usage:
 *   const task = createTask({
 *     fromAgent: 'coordinator',
 *     toAgent: 'researcher',
 *     prompt: 'Research the top 5 competitors in the AI agent space...',
 *     priority: 'P1',
 *   });
 */
export function createTask(input: {
  fromAgent: string;
  toAgent: string;
  prompt: string;
  priority: TaskPriority;
  dependsOn?: string[];
  metadata?: Record<string, unknown>;
}): AgentTask {
  const now = new Date().toISOString();
  return {
    id: `q-${generateId()}`,
    fromAgent: input.fromAgent,
    toAgent: input.toAgent,
    prompt: input.prompt,
    priority: input.priority,
    status: (input.dependsOn && input.dependsOn.length > 0) ? 'blocked' : 'pending',
    dependsOn: input.dependsOn || [],
    resultText: null,
    createdAt: now,
    updatedAt: now,
    completedAt: null,
    retryCount: 0,
    maxRetries: RETRY_CONFIG.maxRetries,
    ttlMinutes: PRIORITY_TTL[input.priority],
    metadata: input.metadata || {},
  };
}

/**
 * Generate a short random ID.
 * In production, use crypto.randomUUID() or similar.
 */
function generateId(): string {
  return Math.random().toString(36).substring(2, 10);
}

// -- Task Queue Helpers --

/**
 * Get the next task an agent should work on.
 * Priority order: P0 > P1 > P2 > P3, then by creation time.
 */
export function getNextTask(agentId: string, tasks: AgentTask[]): AgentTask | null {
  const priorityOrder: TaskPriority[] = ['P0', 'P1', 'P2', 'P3'];

  for (const priority of priorityOrder) {
    const candidates = tasks
      .filter(t =>
        t.toAgent === agentId &&
        t.status === 'pending' &&
        t.priority === priority
      )
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

    if (candidates.length > 0) {
      return candidates[0];
    }
  }

  return null;
}

/**
 * Check if a blocked task's dependencies are all met.
 * If so, transition it to 'pending'.
 */
export function unblockTasks(tasks: AgentTask[]): AgentTask[] {
  const unblocked: AgentTask[] = [];

  for (const task of tasks) {
    if (task.status !== 'blocked') continue;

    const allDepsComplete = task.dependsOn.every(depId => {
      const dep = tasks.find(t => t.id === depId);
      return dep && dep.status === 'completed';
    });

    if (allDepsComplete) {
      task.status = 'pending';
      task.updatedAt = new Date().toISOString();
      unblocked.push(task);
    }
  }

  return unblocked;
}

/**
 * Cancel expired tasks based on TTL.
 */
export function cancelExpiredTasks(tasks: AgentTask[]): AgentTask[] {
  const now = Date.now();
  const cancelled: AgentTask[] = [];

  for (const task of tasks) {
    if (task.status === 'completed' || task.status === 'cancelled' || task.status === 'failed') continue;

    const created = new Date(task.createdAt).getTime();
    const ttlMs = task.ttlMinutes * 60 * 1000;

    if (now - created > ttlMs) {
      task.status = 'cancelled';
      task.updatedAt = new Date().toISOString();
      task.resultText = `Auto-cancelled: exceeded TTL of ${task.ttlMinutes} minutes`;
      cancelled.push(task);
    }
  }

  return cancelled;
}
