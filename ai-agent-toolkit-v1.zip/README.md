# The AI Agent Toolkit

The exact templates, configs, and architecture from a 16-agent production system running on $207/month.

## What's Inside

```
ai-agent-toolkit/
├── souls/                          # Agent personality + instruction templates
│   ├── coordinator.md              # Chief of Staff / task router
│   ├── researcher.md               # Research analyst
│   ├── sales-intel.md              # Sales intelligence specialist
│   ├── content-strategist.md       # Content strategy
│   └── finance-analyst.md          # Budget & P&L tracking
├── config/
│   ├── budget-routing.ts           # 3-tier LLM routing (local → flat-rate → API)
│   └── tool-limits.json            # Per-agent tool allocation (7-10 max)
├── src/
│   └── task-schema.ts              # Inter-agent task delegation system
├── docs/
│   └── deployment-playbook.md      # 60-day week-by-week deployment guide
└── templates/
    └── agent-pnl-tracker.md        # Weekly cost/revenue tracking template
```

## Quick Start

1. Read `docs/deployment-playbook.md` first — it's the roadmap
2. Pick 2-3 soul templates from `souls/` that match your needs
3. Set up budget routing using `config/budget-routing.ts`
4. Restrict tools using `config/tool-limits.json`
5. Add task delegation with `src/task-schema.ts` when you hit 4+ agents

## Stack

- **Runtime:** Bun (or Node)
- **Local LLM:** Ollama with qwen2.5 (3b for routing, 14b for simple tasks)
- **Cloud LLM:** Claude Max ($200/month) or any provider
- **Database:** SQLite
- **Hardware:** Mac Mini M4 Pro (or any Apple Silicon / Linux box)

## The Rules

1. Start with 2-3 agents, not 16
2. 7-10 tools per agent, maximum
3. Budget routing from day 1
4. Tasks, not messages, for inter-agent communication
5. Measure everything — kill agents that don't earn

## Questions?

Subscribe to [The $200/Month CEO](https://buttondown.com/the200dollarceo) for weekly updates on what's working and what's breaking.
